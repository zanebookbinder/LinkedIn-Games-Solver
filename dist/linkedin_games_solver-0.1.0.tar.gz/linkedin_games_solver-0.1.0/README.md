# LinkedIn-Games-Solver

Contains solvers for three LinkedIn games:
* Tango
* Queens
* Zip

